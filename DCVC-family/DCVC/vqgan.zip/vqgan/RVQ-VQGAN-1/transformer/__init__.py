# VQGAN Transformer 压缩模块
