# 使 VQGAN/train 成为可导入的顶层包（可选）

