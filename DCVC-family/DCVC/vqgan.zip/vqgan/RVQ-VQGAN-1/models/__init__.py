# 使 VQGAN/models 成为可导入的顶层包（配合 VQGAN/train/train.py 的 sys.path 注入）

