try:
    from models.taming.modules.losses.vqperceptual import DummyLoss
except ImportError:
    from taming.modules.losses.vqperceptual import DummyLoss

